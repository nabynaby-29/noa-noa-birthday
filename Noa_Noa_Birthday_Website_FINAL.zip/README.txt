NOA NOA BIRTHDAY WEBSITE — PERSONALIZED

Password: 2909
Song: honeybee — Olivia Rodrigo
Four photos are included.

Files:
index.html
photo1.jpg
photo2.jpg
photo3.jpg
photo4.jpg

The site is ready to upload to a static host such as GitHub Pages.
